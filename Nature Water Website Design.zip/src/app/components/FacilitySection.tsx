import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { Factory, Shield, Award, Users } from 'lucide-react';

export function FacilitySection() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById('facility');
    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, []);

  const stats = [
    { icon: Factory, value: '50,000+', label: 'Bottles per Day' },
    { icon: Shield, value: '100%', label: 'Quality Assured' },
    { icon: Award, value: 'ISO 9001', label: 'Certified' },
    { icon: Users, value: '200+', label: 'Team Members' },
  ];

  return (
    <section id="facility" className="py-24 bg-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <h2 className="font-['Montserrat'] text-[#4567b7] text-4xl md:text-5xl mb-6">
              State-of-the-Art Facility
            </h2>
            <p className="text-gray-600 text-lg mb-6">
              Our modern bottling facility in Karachi's Korangi Industrial Area is equipped 
              with the latest technology to ensure the highest quality standards. Every bottle 
              is produced in a controlled environment with strict hygiene protocols.
            </p>
            <p className="text-gray-600 text-lg mb-8">
              From source to bottle, we maintain complete transparency and quality control 
              at every stage of production, ensuring that you receive only the purest, 
              most natural water possible.
            </p>

            <div className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={isVisible ? { opacity: 1, y: 0 } : {}}
                  transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                  className="bg-white rounded-xl p-6 shadow-lg"
                >
                  <div className="w-12 h-12 bg-gradient-to-br from-[#4567b7] to-[#3e8e41] rounded-lg flex items-center justify-center mb-3">
                    <stat.icon className="text-white" size={24} />
                  </div>
                  <div className="font-['Montserrat'] text-[#4567b7] text-2xl mb-1">
                    {stat.value}
                  </div>
                  <div className="text-gray-600 text-sm">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1509886246223-cd7fd68f5372?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlciUyMGZhY3RvcnklMjBib3R0bGluZyUyMHBsYW50fGVufDF8fHx8MTc2NjIzNDk1OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Bottling facility"
                className="w-full h-[500px] object-cover"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-white rounded-xl p-6 shadow-xl max-w-xs">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-[#8bc34a] rounded-full flex items-center justify-center">
                  <Shield className="text-white" size={24} />
                </div>
                <div>
                  <div className="font-['Montserrat'] text-[#4567b7]">
                    Hygiene First
                  </div>
                  <div className="text-gray-600 text-sm">
                    International standards
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
