import { Heart, Droplets } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gradient-to-r from-[#4567b7] to-[#3e8e41] text-white py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                <Droplets className="text-[#4567b7]" size={24} />
              </div>
              <div>
                <h3 className="font-['Montserrat']">Nature Water</h3>
                <p className="text-xs text-white/80">Hydrate Naturally</p>
              </div>
            </div>
            <p className="text-white/80 text-sm">
              Pure, natural mineral water from the heart of Pakistan's pristine springs.
            </p>
          </div>

          <div>
            <h4 className="font-['Montserrat'] mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button
                  onClick={() => document.getElementById('home')?.scrollIntoView({ behavior: 'smooth' })}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Home
                </button>
              </li>
              <li>
                <button
                  onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Products
                </button>
              </li>
              <li>
                <button
                  onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  className="text-white/80 hover:text-white transition-colors"
                >
                  Contact
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-['Montserrat'] mb-4">Contact Info</h4>
            <ul className="space-y-2 text-sm text-white/80">
              <li>B-213 Sector 6-F</li>
              <li>Korangi Industrial Area</li>
              <li>Karachi, Pakistan</li>
              <li className="pt-2">(021) 111 628 873</li>
            </ul>
          </div>

          <div>
            <h4 className="font-['Montserrat'] mb-4">Website</h4>
            <a
              href="http://www.naturewater.com.pk"
              target="_blank"
              rel="noopener noreferrer"
              className="text-white/80 hover:text-white transition-colors text-sm"
            >
              www.naturewater.com.pk
            </a>
            <div className="mt-4">
              <h4 className="font-['Montserrat'] mb-2 text-sm">Email</h4>
              <a
                href="mailto:info.naturebottledwater@gmail.com"
                className="text-white/80 hover:text-white transition-colors text-sm break-all"
              >
                info.naturebottledwater@gmail.com
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-white/20 pt-8 text-center">
          <p className="text-white/80 text-sm flex items-center justify-center space-x-2">
            <span>© 2024 Nature Water. Made with</span>
            <Heart className="text-red-400" size={16} fill="currentColor" />
            <span>in Pakistan</span>
          </p>
        </div>
      </div>
    </footer>
  );
}
