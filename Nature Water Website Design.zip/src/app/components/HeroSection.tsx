import { motion } from 'motion/react';
import { Droplets, Leaf, Heart } from 'lucide-react';

export function HeroSection() {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <div
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1660303438321-1e080a41808e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlciUyMGJvdHRsZXMlMjBiYWNrZ3JvdW5kfGVufDF8fHx8MTc2NzExMTgzNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundAttachment: 'fixed',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-[#4567b7]/70 to-[#3e8e41]/70"></div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="font-['Montserrat'] text-white text-5xl md:text-7xl mb-6">
            Nature Water
          </h1>
          <p className="text-white text-xl md:text-3xl mb-12 font-light">
            Hydrate Naturally, Live Purely
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto"
        >
          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-xl">
            <div className="w-16 h-16 bg-[#4567b7] rounded-full flex items-center justify-center mx-auto mb-4">
              <Droplets className="text-white" size={32} />
            </div>
            <h3 className="font-['Montserrat'] text-[#4567b7] mb-2">Pure Source</h3>
            <p className="text-gray-600 text-sm">
              Sourced from pristine natural springs
            </p>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-xl">
            <div className="w-16 h-16 bg-[#8bc34a] rounded-full flex items-center justify-center mx-auto mb-4">
              <Leaf className="text-white" size={32} />
            </div>
            <h3 className="font-['Montserrat'] text-[#3e8e41] mb-2">Eco-Friendly</h3>
            <p className="text-gray-600 text-sm">
              100% recyclable packaging
            </p>
          </div>

          <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-xl">
            <div className="w-16 h-16 bg-[#3e8e41] rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="text-white" size={32} />
            </div>
            <h3 className="font-['Montserrat'] text-[#4567b7] mb-2">Mineral Rich</h3>
            <p className="text-gray-600 text-sm">
              Essential minerals for your health
            </p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-12"
        >
          <button
            onClick={() => document.getElementById('products')?.scrollIntoView({ behavior: 'smooth' })}
            className="bg-white text-[#4567b7] px-8 py-4 rounded-full hover:bg-[#8bc34a] hover:text-white transition-all duration-300 shadow-xl font-['Montserrat']"
          >
            Explore Our Products
          </button>
        </motion.div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-white to-transparent z-10"></div>
    </section>
  );
}