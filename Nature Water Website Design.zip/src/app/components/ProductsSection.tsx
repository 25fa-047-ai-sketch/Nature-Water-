import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { CheckCircle, Leaf, Droplets, ShieldCheck } from 'lucide-react';

export function ProductsSection() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById('products');
    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, []);

  const products = [
    {
      name: '500ml Bottle',
      description: 'Perfect for on-the-go hydration',
      price: 'Rs. 50',
      image: 'https://images.unsplash.com/photo-1749313161898-a7debb2b8154?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwbGFzdGljJTIwd2F0ZXIlMjBib3R0bGUlMjBwcm9kdWN0fGVufDF8fHx8MTc2NjIzNDk1OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      features: ['100% recyclable', 'BPA-free', 'Portable design'],
    },
    {
      name: '1.5L Bottle',
      description: 'Ideal for home and office',
      price: 'Rs. 120',
      image: 'https://images.unsplash.com/photo-1718697674389-314687dcde2c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5lcmFsJTIwd2F0ZXIlMjBib3R0bGVzJTIwdHJhbnNwYXJlbnR8ZW58MXx8fHwxNzY2MjM0OTU5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      features: ['Family size', 'Easy grip handle', 'Premium quality'],
    },
    {
      name: '5L Gallon',
      description: 'Best value for families',
      price: 'Rs. 350',
      image: 'https://images.unsplash.com/photo-1701478008235-da625f3d72d5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxib3R0bGVkJTIwd2F0ZXIlMjBnYWxsb24lMjBqdWd8ZW58MXx8fHwxNzY2MjM0OTYxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      features: ['Bulk value', 'Long-lasting', 'Convenient'],
    },
  ];

  const productFeatures = [
    {
      icon: Droplets,
      title: 'Natural Source',
      description: 'Sourced from pristine Himalayan springs',
      color: '#4567b7',
    },
    {
      icon: ShieldCheck,
      title: 'Quality Tested',
      description: 'Rigorous testing at every stage',
      color: '#8bc34a',
    },
    {
      icon: Leaf,
      title: 'Eco-Friendly',
      description: '100% recyclable packaging materials',
      color: '#3e8e41',
    },
  ];

  return (
    <section id="products" className="py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-['Montserrat'] text-[#4567b7] text-4xl md:text-5xl mb-4">
            Our Products
          </h2>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg">
            Pure, natural mineral water available in various sizes to suit your needs
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {products.map((product, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
              className="bg-gradient-to-br from-white to-gray-50 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group"
            >
              <div className="relative overflow-hidden h-64 bg-gradient-to-br from-[#4567b7]/10 to-[#3e8e41]/10">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute top-4 right-4 bg-[#8bc34a] text-white px-4 py-2 rounded-full">
                  {product.price}
                </div>
              </div>
              <div className="p-6">
                <h3 className="font-['Montserrat'] text-[#4567b7] text-2xl mb-2">
                  {product.name}
                </h3>
                <p className="text-gray-600 mb-4">{product.description}</p>
                <ul className="space-y-2 mb-6">
                  {product.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center space-x-2">
                      <CheckCircle className="text-[#8bc34a] flex-shrink-0" size={18} />
                      <span className="text-gray-700 text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>
                <button className="w-full bg-[#4567b7] text-white py-3 rounded-full hover:bg-[#3e8e41] transition-colors duration-300 font-['Montserrat']">
                  Learn More
                </button>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="bg-gradient-to-r from-[#4567b7] to-[#3e8e41] rounded-3xl p-12 text-white"
        >
          <h3 className="font-['Montserrat'] text-3xl md:text-4xl text-center mb-12">
            Why Choose Nature Water?
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {productFeatures.map((feature, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isVisible ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
                className="text-center"
              >
                <div className="w-20 h-20 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mx-auto mb-4">
                  <feature.icon size={40} />
                </div>
                <h4 className="font-['Montserrat'] text-xl mb-2">{feature.title}</h4>
                <p className="text-white/90">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
