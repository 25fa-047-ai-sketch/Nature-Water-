import { motion } from 'motion/react';
import { useEffect, useState } from 'react';
import { Award, Users, Sparkles, MapPin } from 'lucide-react';

export function AboutSection() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById('about');
    if (element) {
      observer.observe(element);
    }

    return () => {
      if (element) {
        observer.unobserve(element);
      }
    };
  }, []);

  const teamMembers = [
    {
      name: 'Dr. Sarah Ahmed',
      role: 'Chief Quality Officer',
      image: 'https://images.unsplash.com/photo-1576670158706-8d5b044b61da?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHByb2Zlc3Npb25hbCUyMHNjaWVudGlzdHxlbnwxfHx8fDE3NjYyMzQ5NjF8MA&ixlib=rb-4.1.0&q=80&w=400',
    },
    {
      name: 'Muhammad Khan',
      role: 'Operations Director',
      image: 'https://images.unsplash.com/photo-1589458223095-03eee50f0054?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW4lMjBidXNpbmVzcyUyMGV4ZWN1dGl2ZXxlbnwxfHx8fDE3NjYyMzQ5NjF8MA&ixlib=rb-4.1.0&q=80&w=400',
    },
    {
      name: 'Ayesha Malik',
      role: 'Sustainability Lead',
      image: 'https://images.unsplash.com/photo-1642364861013-2c33f2dcfbcf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBwYWtpc3RhbmklMjBidXNpbmVzcyUyMHBlcnNvbnxlbnwxfHx8fDE3NjYyMzQ5NjB8MA&ixlib=rb-4.1.0&q=80&w=400',
    },
  ];

  return (
    <section id="about" className="py-24 bg-gradient-to-b from-white to-gray-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="font-['Montserrat'] text-[#4567b7] text-4xl md:text-5xl mb-4">
            Our Story
          </h2>
          <p className="text-gray-600 max-w-3xl mx-auto text-lg">
            Nature Water was born from a simple belief: that pure, natural hydration should be accessible to everyone. 
            Sourced from pristine springs in Pakistan's northern regions, our water undergoes minimal processing to 
            preserve its natural minerals and purity.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-20 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <img
              src="https://images.unsplash.com/photo-1653299296556-9b779f598e7b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlciUyMGJvdHRsZSUyMG1vdW50YWluJTIwc3ByaW5nJTIwZnJlc2h8ZW58MXx8fHwxNzY3MTEyNDYzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Journey from natural mountain spring to bottled mineral water"
              className="rounded-2xl shadow-2xl w-full h-[400px] object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#4567b7]/80 via-[#4567b7]/20 to-transparent rounded-2xl flex items-end justify-center pb-12">
              <div className="text-center">
                <h3 className="font-['Montserrat'] text-white text-4xl md:text-5xl font-bold drop-shadow-lg">
                  Nature Water
                </h3>
                <p className="text-white/90 text-lg mt-2 drop-shadow-md">
                  Hydrate Naturally, Live Purely
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="space-y-6"
          >
            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-[#4567b7] rounded-lg flex items-center justify-center flex-shrink-0">
                <Award className="text-white" size={24} />
              </div>
              <div>
                <h3 className="font-['Montserrat'] text-[#4567b7] mb-2">Quality Certified</h3>
                <p className="text-gray-600">
                  Certified by international quality standards including ISO 9001 and HACCP
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-[#8bc34a] rounded-lg flex items-center justify-center flex-shrink-0">
                <Sparkles className="text-white" size={24} />
              </div>
              <div>
                <h3 className="font-['Montserrat'] text-[#3e8e41] mb-2">Natural Minerals</h3>
                <p className="text-gray-600">
                  Rich in essential minerals like calcium, magnesium, and potassium
                </p>
              </div>
            </div>

            <div className="flex items-start space-x-4">
              <div className="w-12 h-12 bg-[#3e8e41] rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="text-white" size={24} />
              </div>
              <div>
                <h3 className="font-['Montserrat'] text-[#4567b7] mb-2">Local Source</h3>
                <p className="text-gray-600">
                  Sourced from protected natural springs in the Himalayan foothills
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <div className="text-center mb-12">
            <div className="inline-flex items-center space-x-2 mb-4">
              <Users className="text-[#4567b7]" size={32} />
              <h3 className="font-['Montserrat'] text-[#4567b7] text-3xl">Meet Our Team</h3>
            </div>
            <p className="text-gray-600">
              Dedicated professionals committed to delivering pure, natural water
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {teamMembers.map((member, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={isVisible ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.5 + index * 0.1 }}
                className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-shadow"
              >
                <div className="relative mb-4">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-32 h-32 rounded-full mx-auto object-cover border-4 border-[#4567b7]"
                  />
                </div>
                <h4 className="font-['Montserrat'] text-[#4567b7] text-center mb-2">
                  {member.name}
                </h4>
                <p className="text-gray-600 text-center text-sm">{member.role}</p>
                <div className="flex justify-center space-x-3 mt-4">
                  <a href="#" className="w-8 h-8 bg-[#4567b7] rounded-full flex items-center justify-center hover:bg-[#3e8e41] transition-colors">
                    <span className="text-white text-xs">in</span>
                  </a>
                  <a href="#" className="w-8 h-8 bg-[#4567b7] rounded-full flex items-center justify-center hover:bg-[#3e8e41] transition-colors">
                    <span className="text-white text-xs">tw</span>
                  </a>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}